History
-------

0.1.0 ({{cookiecutter.nope | foobar}})
--------------------------------------

First release on PyPI.
