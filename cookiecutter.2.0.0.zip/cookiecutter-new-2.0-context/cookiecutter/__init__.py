# -*- coding: utf-8 -*-

"""
cookiecutter
------------

Main package for Cookiecutter.
"""

__version__ = '2.0.0-alpha+1.6.0'
